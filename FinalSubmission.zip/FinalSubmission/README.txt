Welcome to "Enemies of the People"!
================================================================================
Creators: Jaells Naranjo and Jianlin Chen

Jaells Naranjo Contributions:
    Created main theme song. An 8bit cover of the Soviet Anthem.
    Wrote the first half of the story
    Designed the title sprite
    
Jianlin Chen:
    Created the rescue Blyukher.

    Final polishing.
    Create the 8bit images we are using.


================================================================================
Walkthrough:
Start -> Go Downstairs -> Read Pravda -> Answer the telephone -> I'll be there 
-> exit -> Leave for meeting -> Can you be more specific -> Why didnt you 
<<<<<<< HEAD
prevent this -> no ->  
=======
prevent this -> no -> continue -> Didnt you order the NKVD officers to leave 
him? -> Ok -> Leave now! -> continue -> continue -> continue -> What is it? ->
Category 1? 
1. For the second part, we included two ends, if the player finds Administrator of the gulag is a German spy, 
the player could use him as a scapegoat for helping Blyukher's escape. 
For doing that play must no kill the guard, 
then the player can go back to the office to carefully exam the map. Failed to do so will result, character, 
been executed for helping Blyukher to escape.
2. There are multiple approaches to escape
	first, 
the player chooses to look around the gulag when arrived, keep looking then will discover 
a hole on the wall to allow player escape from the front door.
	And also the player can check 
the 8 books on the bookshelf in the administrator's office, he will discover a key to unlock sewage, 
and escape from there.